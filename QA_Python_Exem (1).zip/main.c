
int main()
{
    int global = __VALUE__;
    return global;
}